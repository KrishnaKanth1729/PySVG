# PySVG
## The Python library for generating dynamic SVGs using Python3

Note:
    This library is still under development
